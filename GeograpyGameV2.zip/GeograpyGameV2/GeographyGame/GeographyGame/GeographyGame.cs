﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using MySql.Data.MySqlClient;
using System.Drawing;
using MySqlCommand = MySql.Data.MySqlClient.MySqlCommand;
using MySQLConnection = MySql.Data.MySqlClient.MySqlConnection;
using MySqlDataAdapter = MySql.Data.MySqlClient.MySqlDataAdapter;
using MySQLDataReader = MySql.Data.MySqlClient.MySqlDataReader;
namespace GeographyGame
{
    public partial class GeographyGame : Form
    {
        
        List<Country> countries;
        bool selected;
        Random rand;
        string _continent;
        public GeographyGame(string continent)
        {

            InitializeComponent();
            try
            {
                _continent = continent;
                string connectionstring = @"datasource=sql16.freesqldatabase.com;port=3306;database=sql16412717;username=sql6412717;password=9B8lPlBL4v";
                string mySQL = "SELECT * from Countries where Continent = '" + continent + "'";
                MySQLDataReader reader = null;
                MySQLConnection conn = new MySQLConnection(connectionstring);
                MySqlCommand command = new MySqlCommand(mySQL, conn); 
                conn.Open();
                reader = command.ExecuteReader();
                MySql.Data.MySqlClient.MySqlDataAdapter dtb = new MySqlDataAdapter(mySQL, conn);
                
                while (reader.Read())
                {
                    int X = rand.Next(500, pictureBoxDisplay.Width);
                    int Y = rand.Next(0, pictureBoxDisplay.Height);
                    int StatType = rand.Next(4, 7);
                    Country c = new Country(reader.GetString(1), X, Y, int.Parse(reader.GetString(2)), int.Parse(reader.GetString(3)), ulong.Parse(reader.GetString(StatType)));
                    countries.Add(c);
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Source);
            }

        }

        private void trackBarCountryStat_Scroll(object sender, EventArgs e)
        {

        }

        private void UpdateTrackBar()
        { 
            
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            while (true)
            {
                
            }
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {

        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {

        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            foreach (var item in countries)
            {
                item.Draw(e.Graphics, _continent);
            }
        }
    }
}
